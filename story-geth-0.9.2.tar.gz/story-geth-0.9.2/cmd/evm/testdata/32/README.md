This test does some EVM execution, and can be used to test callframes emitted by the tracer when they are enabled.
